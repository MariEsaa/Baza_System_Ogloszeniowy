-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Lis 06, 2023 at 12:38 AM
-- Wersja serwera: 10.4.28-MariaDB
-- Wersja PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemogloszeniowy_baza`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `doswiadczenie_zawodowe`
--

CREATE TABLE `doswiadczenie_zawodowe` (
  `doswiadczenie_zawodowe_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `stanowisko` varchar(100) NOT NULL,
  `nazwa_firmy` varchar(100) NOT NULL,
  `lokalizacja` varchar(100) NOT NULL,
  `okres_zatrudnienia_od` date NOT NULL,
  `okres_zatrudnienia_do` date NOT NULL,
  `obowiazki` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kursy_szkolenia_certyfikaty`
--

CREATE TABLE `kursy_szkolenia_certyfikaty` (
  `kursy_szkolenia_certyfikaty_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `nazwa_szkolenia` varchar(100) NOT NULL,
  `organizator` varchar(100) NOT NULL,
  `data_odbycia` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `linki`
--

CREATE TABLE `linki` (
  `linki_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `link` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `podsumowanie_zawodowe`
--

CREATE TABLE `podsumowanie_zawodowe` (
  `podsumowanie_zawodowe_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `podsumowanie` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownik`
--

CREATE TABLE `pracownik` (
  `pracownik_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `stanowisko_id` int(11) NOT NULL,
  `podsumowanie_zawodowe_id` int(11) NOT NULL,
  `doswiadczenie_zawodowe_id` int(11) NOT NULL,
  `wyksztalcenie_id` int(11) NOT NULL,
  `znajomosc_jezykow_id` int(11) NOT NULL,
  `umiejetnosci_id` int(11) NOT NULL,
  `kursy_szkolenia_certyfikaty_id` int(11) NOT NULL,
  `linki_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `stanowisko`
--

CREATE TABLE `stanowisko` (
  `stanowisko_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `stanowisko` varchar(100) NOT NULL,
  `opis_stanowiska` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `umiejetnosci`
--

CREATE TABLE `umiejetnosci` (
  `umiejetnosci_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `umiejetnosc` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `uzytkownik`
--

CREATE TABLE `uzytkownik` (
  `uzytkownik_id` int(11) NOT NULL,
  `imie` varchar(100) NOT NULL,
  `nazwisko` varchar(100) NOT NULL,
  `data_urodzenia` date NOT NULL,
  `adres_email` varchar(100) NOT NULL,
  `numer_telefonu` varchar(9) NOT NULL,
  `zdjecie_profilowe` varchar(1000) NOT NULL,
  `miejsce_zamieszkania` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wyksztalcenie`
--

CREATE TABLE `wyksztalcenie` (
  `wyksztalcenie_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `nazwa_szkoly_uczelni` varchar(100) NOT NULL,
  `miejscowosc` varchar(100) NOT NULL,
  `poziom_wyksztalcenie` enum('podstawowe','zawodowe','średnie','licencjat','magister','doktor') NOT NULL,
  `kierunek` varchar(100) NOT NULL,
  `okres_od` date DEFAULT NULL,
  `okres_do` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `znajomosc_jezykow`
--

CREATE TABLE `znajomosc_jezykow` (
  `znajomosc_jezykow_id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `jezyk` varchar(100) NOT NULL,
  `poziom` enum('podstawowy','średniozaawansowany','zaawansowany','A1','A2','B1','B2','C1','C2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `doswiadczenie_zawodowe`
--
ALTER TABLE `doswiadczenie_zawodowe`
  ADD PRIMARY KEY (`doswiadczenie_zawodowe_id`);

--
-- Indeksy dla tabeli `kursy_szkolenia_certyfikaty`
--
ALTER TABLE `kursy_szkolenia_certyfikaty`
  ADD PRIMARY KEY (`kursy_szkolenia_certyfikaty_id`);

--
-- Indeksy dla tabeli `linki`
--
ALTER TABLE `linki`
  ADD PRIMARY KEY (`linki_id`);

--
-- Indeksy dla tabeli `podsumowanie_zawodowe`
--
ALTER TABLE `podsumowanie_zawodowe`
  ADD PRIMARY KEY (`podsumowanie_zawodowe_id`);

--
-- Indeksy dla tabeli `pracownik`
--
ALTER TABLE `pracownik`
  ADD PRIMARY KEY (`pracownik_id`),
  ADD KEY `uzytkownik_id` (`uzytkownik_id`),
  ADD KEY `stanowisko_id` (`stanowisko_id`),
  ADD KEY `podsumowanie_zawodowe_id` (`podsumowanie_zawodowe_id`),
  ADD KEY `doswiadczenie_zawodowe_id` (`doswiadczenie_zawodowe_id`),
  ADD KEY `wyksztalcenie_id` (`wyksztalcenie_id`),
  ADD KEY `znajomosc_jezykow_id` (`znajomosc_jezykow_id`),
  ADD KEY `umiejetnosci_id` (`umiejetnosci_id`),
  ADD KEY `kursy_szkolenia_certyfikaty_id` (`kursy_szkolenia_certyfikaty_id`),
  ADD KEY `linki_id` (`linki_id`);

--
-- Indeksy dla tabeli `stanowisko`
--
ALTER TABLE `stanowisko`
  ADD PRIMARY KEY (`stanowisko_id`);

--
-- Indeksy dla tabeli `umiejetnosci`
--
ALTER TABLE `umiejetnosci`
  ADD PRIMARY KEY (`umiejetnosci_id`);

--
-- Indeksy dla tabeli `uzytkownik`
--
ALTER TABLE `uzytkownik`
  ADD PRIMARY KEY (`uzytkownik_id`);

--
-- Indeksy dla tabeli `wyksztalcenie`
--
ALTER TABLE `wyksztalcenie`
  ADD PRIMARY KEY (`wyksztalcenie_id`);

--
-- Indeksy dla tabeli `znajomosc_jezykow`
--
ALTER TABLE `znajomosc_jezykow`
  ADD PRIMARY KEY (`znajomosc_jezykow_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doswiadczenie_zawodowe`
--
ALTER TABLE `doswiadczenie_zawodowe`
  MODIFY `doswiadczenie_zawodowe_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kursy_szkolenia_certyfikaty`
--
ALTER TABLE `kursy_szkolenia_certyfikaty`
  MODIFY `kursy_szkolenia_certyfikaty_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `linki`
--
ALTER TABLE `linki`
  MODIFY `linki_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `podsumowanie_zawodowe`
--
ALTER TABLE `podsumowanie_zawodowe`
  MODIFY `podsumowanie_zawodowe_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pracownik`
--
ALTER TABLE `pracownik`
  MODIFY `pracownik_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stanowisko`
--
ALTER TABLE `stanowisko`
  MODIFY `stanowisko_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `umiejetnosci`
--
ALTER TABLE `umiejetnosci`
  MODIFY `umiejetnosci_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uzytkownik`
--
ALTER TABLE `uzytkownik`
  MODIFY `uzytkownik_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wyksztalcenie`
--
ALTER TABLE `wyksztalcenie`
  MODIFY `wyksztalcenie_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `znajomosc_jezykow`
--
ALTER TABLE `znajomosc_jezykow`
  MODIFY `znajomosc_jezykow_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pracownik`
--
ALTER TABLE `pracownik`
  ADD CONSTRAINT `pracownik_ibfk_1` FOREIGN KEY (`uzytkownik_id`) REFERENCES `uzytkownik` (`uzytkownik_id`),
  ADD CONSTRAINT `pracownik_ibfk_2` FOREIGN KEY (`stanowisko_id`) REFERENCES `stanowisko` (`stanowisko_id`),
  ADD CONSTRAINT `pracownik_ibfk_3` FOREIGN KEY (`podsumowanie_zawodowe_id`) REFERENCES `podsumowanie_zawodowe` (`podsumowanie_zawodowe_id`),
  ADD CONSTRAINT `pracownik_ibfk_4` FOREIGN KEY (`doswiadczenie_zawodowe_id`) REFERENCES `doswiadczenie_zawodowe` (`doswiadczenie_zawodowe_id`),
  ADD CONSTRAINT `pracownik_ibfk_5` FOREIGN KEY (`wyksztalcenie_id`) REFERENCES `wyksztalcenie` (`wyksztalcenie_id`),
  ADD CONSTRAINT `pracownik_ibfk_6` FOREIGN KEY (`znajomosc_jezykow_id`) REFERENCES `znajomosc_jezykow` (`znajomosc_jezykow_id`),
  ADD CONSTRAINT `pracownik_ibfk_7` FOREIGN KEY (`umiejetnosci_id`) REFERENCES `umiejetnosci` (`umiejetnosci_id`),
  ADD CONSTRAINT `pracownik_ibfk_8` FOREIGN KEY (`kursy_szkolenia_certyfikaty_id`) REFERENCES `kursy_szkolenia_certyfikaty` (`kursy_szkolenia_certyfikaty_id`),
  ADD CONSTRAINT `pracownik_ibfk_9` FOREIGN KEY (`linki_id`) REFERENCES `linki` (`linki_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
